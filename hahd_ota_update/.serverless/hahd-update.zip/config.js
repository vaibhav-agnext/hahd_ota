//current desired version for test rack devices
const test_version=8;

//current desired version for production devices
const prod_version=8;

const dev_version = 8;

var dev_devices_list = [];

var test_devices_list = [];


module.exports = {
    test_version,
    prod_version,
    dev_devices_list,
    test_devices_list,
    dev_version
}